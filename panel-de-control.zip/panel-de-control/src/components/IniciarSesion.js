export function IniciarSesion() {
    return <h1>Iniciar Sesion</h1>
}