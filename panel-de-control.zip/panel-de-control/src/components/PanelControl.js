export function PanelControl() {
    return <h1>Panel Control</h1>
}