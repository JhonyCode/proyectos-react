import logo from './logo.svg';
import './App.css';
import { PanelControl } from './components/PanelControl';
import { Autenticacion } from './components/Autenticacion';

// 1. Crear un component IniciarSesion
// 2. Crear un component PanelControl
// 3. Renderizar IniciarSesion cuando isLoggedIn = false y 
//    renderizar PanelControl cuando isLoggedIn = true

// 4. Crear un component Autenticacion
// 5. Si está isLoggedIn renderizar props.children, sino, IniciarSesión

function App() {
  const isLoggedIn = true

  return (
    <Autenticacion isLoggedIn={isLoggedIn}>
     <PanelControl />
    </Autenticacion>
  );
}

export default App;
