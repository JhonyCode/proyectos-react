export const NotFound =() =>  {
    return <h1>NotFound</h1>
}